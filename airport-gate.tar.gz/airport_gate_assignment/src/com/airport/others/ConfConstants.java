package com.airport.others;

/**
 * Constant class
 * 
 * @author babu
 *
 */
public class ConfConstants {

	public static final String NO_GATES_AVAILABLE = "NO GATES AVAILABLE";

	public static final String DUPLICATE_AIRCRAFT_REQUEST = "GATE ALREADY ASSIGNED TO AIRCRAFT";

	public static final String FLIGHT_NOT_IN_GATE = "FLIGHT NOT IN GATE";

	public static final String RESULT_NO_VALUE = "NONE";

	// Input params
	public static final String NUM_GATES = "NUM_GATES";
	public static final String QUIT = "quit";;

}
