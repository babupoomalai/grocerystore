package com.airport.others;

/**
 * Util class for common functions
 * 
 * @author babu
 *
 */
public class AircraftUtil {

	public static boolean isEmpty(String text) {
		return text == null || text.trim().equals("");
	}

}
