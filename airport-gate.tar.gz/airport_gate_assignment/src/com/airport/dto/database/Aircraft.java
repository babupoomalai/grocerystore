package com.airport.dto.database;

/**
 * Dto Class to represent aircraft and its properties
 * 
 * @author babu
 *
 */
public class Aircraft {

	private String num;

	private String source;

	private String destination;

	public Aircraft(String num, String source, String destination) {
		super();
		this.num = num;
		this.source = source;
		this.destination = destination;
	}

	public String getNum() {
		return num;
	}

	public String getSource() {
		return source;
	}

	public String getDestination() {
		return destination;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((num == null) ? 0 : num.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Aircraft other = (Aircraft) obj;
		if (num == null) {
			if (other.num != null)
				return false;
		} else if (!num.equals(other.num))
			return false;
		return true;
	}

}
