package com.airport.dto.pages;

import com.airport.dto.database.Aircraft;

/**
 * Wrapper class for Airport assignment
 * 
 * @author babu
 *
 */
public class AircraftAssignment {

	private int gate;

	private Aircraft aircraft;

	public AircraftAssignment(int gate, Aircraft aircraft) {
		super();
		this.gate = gate;
		this.aircraft = aircraft;
	}

	public int getGate() {
		return gate;
	}

	public Aircraft getAircraft() {
		return aircraft;
	}

}
