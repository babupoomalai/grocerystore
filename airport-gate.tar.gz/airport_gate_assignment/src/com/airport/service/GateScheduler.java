package com.airport.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.Queue;
import java.util.stream.Collectors;

import com.airport.dto.database.Aircraft;
import com.airport.dto.pages.AircraftAssignment;
import com.airport.others.AircraftUtil;
import com.airport.others.ConfConstants;

/**
 * Class to request to land, leave, get other stats of aircrafts landed
 * 
 * @author babu
 *
 */
public class GateScheduler {

	private int gateSize;

	// Map to maintain aircraft assignment details
	private LinkedHashMap<String, AircraftAssignment> aircraftAssignmentMap = new LinkedHashMap<>();

	// List of free gates available
	private Queue<Integer> availableGate = new LinkedList<>();

	public GateScheduler(int size) {
		this.gateSize = size;
		for (int i = 1; i <= size; i++) {
			availableGate.add(i);
		}
	}

	/**
	 * Function to assign gate for requested aircraft
	 * 
	 * @param aircraft
	 *            details about aircraft
	 * @return {aircraft with gate id} id assigned {No Gates available}
	 *         otherwise
	 */
	public String requestGate(Aircraft aircraft) {
		// If no gates are available
		if (availableGate.size() == 0) {
			return ConfConstants.NO_GATES_AVAILABLE;
		}
		String aircraftNum = aircraft.getNum();
		if (aircraftAssignmentMap.containsKey(aircraftNum)) {
			return ConfConstants.DUPLICATE_AIRCRAFT_REQUEST;
		}

		Integer gate = availableGate.poll();
		aircraftAssignmentMap.put(aircraftNum, new AircraftAssignment(gate, aircraft));
		return "ALLOCATED GATE " + gate + " FOR " + aircraftNum;
	}

	/**
	 * Function to free the gate assigned to requested aircraft num
	 * 
	 * @param aircraftNum
	 *            details about aircraft
	 * @return {gateId} id freed {-1} if no gates assigned for the aircraft
	 */
	public String leaveGate(String aircraftNum) {
		AircraftAssignment aircraftAssignment = aircraftAssignmentMap.get(aircraftNum);
		// if aircraft not landed in any gate
		if (aircraftAssignment == null) {
			return ConfConstants.FLIGHT_NOT_IN_GATE;
		}

		int gateAssigned = aircraftAssignment.getGate();
		availableGate.add(gateAssigned);
		aircraftAssignmentMap.remove(aircraftNum);

		return aircraftNum + " IS LEAVING GATE " + gateAssigned;
	}

	/*
	 * Function to return the aircrafts landed and asisgned to gate
	 */
	public String status() {
		StringBuilder resultBuilder = new StringBuilder();
		if (aircraftAssignmentMap.size() == 0) {
			return "NO FLIGHTS ASSIGNED";
		}

		ArrayList<AircraftAssignment> list = new ArrayList<>(aircraftAssignmentMap.values());
		// Sort details by Gate id (output readability)
		Collections.sort(list, new Comparator<AircraftAssignment>() {

			@Override
			public int compare(AircraftAssignment o1, AircraftAssignment o2) {
				return Integer.valueOf(o1.getGate()).compareTo(Integer.valueOf(o2.getGate()));
			}
		});

		resultBuilder.append("GATE\tFLIGHT\tORIGIN\tDESTINATION");
		for (AircraftAssignment aircraftAssignment : list) {
			Aircraft aircraft = aircraftAssignment.getAircraft();
			String source = AircraftUtil.isEmpty(aircraft.getSource()) ? "None" : aircraft.getSource();
			String destination = AircraftUtil.isEmpty(aircraft.getDestination()) ? "None" : aircraft.getDestination();
			resultBuilder.append("\n" + aircraftAssignment.getGate() + "\t" + aircraft.getNum() + "\t" + source + "\t"
					+ destination);
		}
		return resultBuilder.toString();
	}

	/*
	 * Function to get gate id for aircraft if landed
	 */
	public String getGateDetails(String aircraftNum) {
		AircraftAssignment aircraftAssignment = aircraftAssignmentMap.get(aircraftNum);
		if (aircraftAssignment == null) {
			return ConfConstants.FLIGHT_NOT_IN_GATE;
		}

		return String.valueOf(aircraftAssignment.getGate());
	}

	/*
	 * Function to get gate details of aircrafts whose source is given value
	 */
	public String getGatesFromAirport(String source) {
		if (aircraftAssignmentMap.size() == 0 || AircraftUtil.isEmpty(source)) {
			return ConfConstants.RESULT_NO_VALUE;
		}

		// Sort by gate and transform the list to hold only gate ids.
		String result = aircraftAssignmentMap.values().stream()
				.filter(o -> source.equalsIgnoreCase(o.getAircraft().getSource()))
				.sorted(new Comparator<AircraftAssignment>() {

					@Override
					public int compare(AircraftAssignment o1, AircraftAssignment o2) {
						return Integer.valueOf(o1.getGate()).compareTo(Integer.valueOf(o2.getGate()));
					}
				}).map(e -> String.valueOf(e.getGate())).collect(Collectors.joining(", "));

		return AircraftUtil.isEmpty(result) ? ConfConstants.RESULT_NO_VALUE : result;
	}

	/*
	 * Function to get aircraft details of aircrafts whose destination is given
	 * value
	 */
	public String getAircraftsDestined(String destination) {
		if (aircraftAssignmentMap.size() == 0 || AircraftUtil.isEmpty(destination)) {
			return ConfConstants.RESULT_NO_VALUE;
		}

		// Sort by gate and transform the list to hold only aircraft num.

		String result = aircraftAssignmentMap.values().stream()
				.filter(o -> destination.equalsIgnoreCase(o.getAircraft().getDestination()))
				.sorted(new Comparator<AircraftAssignment>() {

					@Override
					public int compare(AircraftAssignment o1, AircraftAssignment o2) {
						return Integer.valueOf(o1.getGate()).compareTo(Integer.valueOf(o2.getGate()));
					}
				}).map(e -> e.getAircraft().getNum()).collect(Collectors.joining(", "));
		return AircraftUtil.isEmpty(result) ? ConfConstants.RESULT_NO_VALUE : result;

	}

	public int getGateSize() {
		return gateSize;
	}

}
