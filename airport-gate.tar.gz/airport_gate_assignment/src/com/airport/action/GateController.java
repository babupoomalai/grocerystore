package com.airport.action;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.airport.dto.database.Aircraft;
import com.airport.others.ConfConstants;
import com.airport.service.GateScheduler;

/**
 * Main class to read the inputs from user and process it
 * 
 * @author babu
 *
 */
public class GateController {

	private static GateScheduler gateScheduler = null;

	public static void main(String args[]) {
		boolean isConsoleInput = false;
		if (args.length == 0) {
			isConsoleInput = true;
		}

		// If Console Input
		if (isConsoleInput) {
			while (true) {
				BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
				try {
					String input = reader.readLine();

					System.out.println(readInput(input));
					if (ConfConstants.QUIT.equalsIgnoreCase(input)) {
						reader.close();
						return;
					}

				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			// If read from input file
		} else {
			String fileName = args[0];
			readFile(fileName);
		}
	}

	private static String readInput(String input) {
		input = input.trim();
		if (ConfConstants.QUIT.equalsIgnoreCase(input)) {
			return "BYE BYE";
		}

		// Init request
		Pattern initPattern = Pattern.compile("num_gate[s]? ([0-9]+)", Pattern.CASE_INSENSITIVE);
		Matcher matcher = initPattern.matcher(input);
		if (matcher.find()) {
			String groupText = matcher.group(1);
			int group = Integer.parseInt(groupText);
			gateScheduler = new GateScheduler(group);
			return "INIT " + groupText + " GATE" + (group == 1 ? "" : "S");
		}

		// Request gate
		Pattern requestPattern = Pattern.compile("request ([a-z0-9]+) ([a-z]+) ([a-z]+)", Pattern.CASE_INSENSITIVE);
		Matcher requestMatcher = requestPattern.matcher(input);
		if (requestMatcher.find()) {
			String aircraftNum = requestMatcher.group(1);
			String source = requestMatcher.group(2);
			String destination = requestMatcher.group(3);
			return gateScheduler.requestGate(new Aircraft(aircraftNum, source, destination));
		}

		// Leave gate
		Pattern leavePattern = Pattern.compile("leave ([a-z0-9]+)", Pattern.CASE_INSENSITIVE);
		Matcher leaveMatcher = leavePattern.matcher(input);
		if (leaveMatcher.find()) {
			String aircraftNum = leaveMatcher.group(1);
			return gateScheduler.leaveGate(aircraftNum);
		}

		// Status
		Pattern statusPattern = Pattern.compile("status", Pattern.CASE_INSENSITIVE);
		Matcher statusMatcher = statusPattern.matcher(input);
		if (statusMatcher.find()) {
			return gateScheduler.status();
		}

		// Gate
		Pattern gatePattern = Pattern.compile("gate ([a-z0-9]+)", Pattern.CASE_INSENSITIVE);
		Matcher gateMatcher = gatePattern.matcher(input);
		if (gateMatcher.find()) {
			String aircraftNum = gateMatcher.group(1);
			return gateScheduler.getGateDetails(aircraftNum);
		}

		// Flying To
		Pattern flyingToPattern = Pattern.compile("flying_to ([a-z]+)", Pattern.CASE_INSENSITIVE);
		Matcher flyingToMatcher = flyingToPattern.matcher(input);
		if (flyingToMatcher.find()) {
			String destination = flyingToMatcher.group(1);
			return gateScheduler.getAircraftsDestined(destination);
		}

		// Gates from
		Pattern gatesFromPattern = Pattern.compile("gates_from ([a-z]+)", Pattern.CASE_INSENSITIVE);
		Matcher gatesFromMatcher = gatesFromPattern.matcher(input);
		if (gatesFromMatcher.find()) {
			String source = gatesFromMatcher.group(1);
			return gateScheduler.getGatesFromAirport(source);
		}

		return "No matched command found";
	}

	private static void readFile(String fileName) {
		File file = new File(fileName);
		List<String> lineList = new ArrayList<>();

		try (BufferedReader br = new BufferedReader(new FileReader(file))) {
			for (String line; (line = br.readLine()) != null;) {

				lineList.add(readInput(line));
				if (ConfConstants.QUIT.equalsIgnoreCase(line)) {
					writeToFile(file.getParent(), lineList);
					br.close();
					return;
				}
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		writeToFile(file.getParent(), lineList);
	}

	private static void writeToFile(String parentDir, List<String> lineList) {
		try {
			String fileName = (parentDir != null ? parentDir + "/" : "") + "1_out.text";
			Files.write(Paths.get(fileName), lineList, Charset.forName("UTF-8"));
		} catch (IOException e) {
			e.printStackTrace();
		}

	}
}
