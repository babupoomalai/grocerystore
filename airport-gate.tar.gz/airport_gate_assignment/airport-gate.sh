#!/bin/bash

ARGS_EXPECTED=1

java -cp airport-gate.jar com.airport.action.GateController $1