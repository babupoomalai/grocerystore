package com.airport.others;

import static org.junit.Assert.*;

import org.junit.Test;

public class AirtcraftUtilTest {

	@Test
	public void testIsEmpty() {
		assertTrue(AircraftUtil.isEmpty(""));
		assertTrue(AircraftUtil.isEmpty("   "));
 		assertTrue(AircraftUtil.isEmpty(null));

		assertFalse(AircraftUtil.isEmpty("value"));
	}

}
