package com.airport.action;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

import com.airport.others.AirtcraftUtilTest;
import com.airport.service.GateSchedulerTest;

@RunWith(Suite.class)
@SuiteClasses({ AirtcraftUtilTest.class, GateSchedulerTest.class })
public class AllTests {

}
