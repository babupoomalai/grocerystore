package com.airport.service;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;

import com.airport.dto.database.Aircraft;
import com.airport.others.ConfConstants;

public class GateSchedulerTest {

	private GateScheduler instance;

	// Initialize the gate scheduler with n gates
	@Before
	public void initalizeGateScheduler() {
		this.instance = new GateScheduler(4);
	}

	// Test request gate in +ve condition
	@Test
	public void testRequestGate() {
		assertEquals("ALLOCATED GATE 1 FOR AI623", instance.requestGate(new Aircraft("AI623", "MAA", "BOM")));
		assertEquals("ALLOCATED GATE 2 FOR AI624", instance.requestGate(new Aircraft("AI624", "", "BOM")));
		assertEquals("ALLOCATED GATE 3 FOR AI625", instance.requestGate(new Aircraft("AI625", "CJB", null)));
		assertEquals("ALLOCATED GATE 4 FOR AI626", instance.requestGate(new Aircraft("AI626", "BOM", "")));
	}

	@Test
	public void testFailRequestGateIfAllGatesOccupied() {
		instance.requestGate(new Aircraft("AI623", "MAA", "BOM"));
		instance.requestGate(new Aircraft("AI624", "MAA", "BOM"));
		instance.requestGate(new Aircraft("AI625", "MAA", "BOM"));
		instance.requestGate(new Aircraft("AI626", "MAA", "BOM"));
		assertEquals(ConfConstants.NO_GATES_AVAILABLE, instance.requestGate(new Aircraft("AI627", "MAA", "BOM")));
	}

	@Test
	public void testFailRequestGateIfDuplicateAircraftRequest() {
		instance.requestGate(new Aircraft("AI623", "MAA", "BOM"));
		assertEquals(ConfConstants.DUPLICATE_AIRCRAFT_REQUEST,
				instance.requestGate(new Aircraft("AI623", "MAA", "BOM")));
	}

	@Test
	public void testLeaveGate() {
		instance.requestGate(new Aircraft("AI623", "MAA", "BOM"));
		instance.requestGate(new Aircraft("AI624", "MAA", "BOM"));
		assertEquals("AI624 IS LEAVING GATE 2", instance.leaveGate("AI624"));
	}

	@Test
	public void testFailLeaveGateWithUnknownAircraft() {
		instance.requestGate(new Aircraft("AI623", "MAA", "BOM"));
		instance.requestGate(new Aircraft("AI624", "MAA", "BOM"));
		assertEquals(ConfConstants.FLIGHT_NOT_IN_GATE, instance.leaveGate("AI625"));
	}

	@Test
	public void testFailLeaveGateWithNullValue() {
		instance.requestGate(new Aircraft("AI623", "MAA", "BOM"));
		instance.requestGate(new Aircraft("AI624", "MAA", "BOM"));
		assertEquals(ConfConstants.FLIGHT_NOT_IN_GATE, instance.leaveGate(null));
	}

	@Test
	public void testGetGateDetails() {
		instance.requestGate(new Aircraft("AI623", "MAA", "BOM"));
		instance.requestGate(new Aircraft("AI624", "MAA", "BOM"));
		assertEquals("2", instance.getGateDetails("AI624"));
	}

	@Test
	public void testGetGateDetailsWithUnknownAircraft() {
		instance.requestGate(new Aircraft("AI623", "MAA", "BOM"));
		instance.requestGate(new Aircraft("AI624", "MAA", "BOM"));
		assertEquals(ConfConstants.FLIGHT_NOT_IN_GATE, instance.getGateDetails("AI629"));
	}

	@Test
	public void testGetGatesFromAirport() {
		instance.requestGate(new Aircraft("AI623", "MAA", "BOM"));
		instance.requestGate(new Aircraft("AI624", "MAA", "BOM"));
		assertEquals("1, 2", instance.getGatesFromAirport("MAA"));
	}

	@Test
	public void testGetGatesFromNonExistingAirport() {
		instance.requestGate(new Aircraft("AI623", "MAA", "BOM"));
		instance.requestGate(new Aircraft("AI624", "MAA", "BOM"));
		assertEquals(ConfConstants.RESULT_NO_VALUE, instance.getGatesFromAirport("CJB"));
	}

	@Test
	public void testGetAircraftDestined() {
		instance.requestGate(new Aircraft("AI623", "MAA", "BOM"));
		instance.requestGate(new Aircraft("AI624", "MAA", "CJB"));
		instance.requestGate(new Aircraft("AI625", "MAA", "BOM"));
		assertEquals("AI624", instance.getAircraftsDestined("CJB"));
		assertEquals("AI623, AI625", instance.getAircraftsDestined("BOM"));
	}

}
